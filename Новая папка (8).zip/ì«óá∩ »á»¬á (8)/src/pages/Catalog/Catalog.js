function Catalog() {
    return(
        <div>
            <h1>Catalog</h1>
        </div>
    );
}
export default Catalog;