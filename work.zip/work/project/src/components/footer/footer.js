import React from 'react';
import styles from './footer.css';
// import FooterLink from './footerLink';

const Footer = () => {
    return (
            <div className="container">
                <div className="background">
                    <h1>Златоустовские ножи интернет-магазин "ЗЛАТМАКС"</h1>
                    <p>Наш интернет-магазин "ЗЛАТМАКС" предлагает Вам ножи очень высокого качества из города оружейников - Златоуста. Златоустовские ножи известны и популярны среди потребителей как на российским рынке, так и за рубежом: ножи охотничьи, хозяйственные, туристические, рыбацкие, складные и метательные. Нож Златоуста - это идеальный друг и товарищ в повседневной жизни и в экстремальных ситуациях. На многую продукцию распространяется гарантия до 10 лет - это один из главных показателей качества. Для Вас на нашем сайте "zlatmax" предложен огромный ассортимент Златоустовских ножей. Наши менеджеры помогут определиться и подобрать самый лучший Златоустовский нож, ориентируясь на Ваши пожелания.</p>
                </div>

            </div>
    );
};

export default Footer;



































{/* <div className="footerDiv">
    <div className="info">
        <h4>ИНФОРМАЦИЯ</h4>
        <FooterLink label="Златоустовские ножи в Москве и Московской области" href="/" />
        <FooterLink label="Ножевые стали" href="/" />
        <FooterLink label="О нас" href="/about" />
        <FooterLink label="Условия оплаты и доставки" href="/pay" />
        <FooterLink label="Политика конфиденциальности" href="/confed" />
    </div>
    <div className= "infoTwo">
        <h4>СЛУЖБА ПОДДЕРЖКИ</h4>
        <FooterLink label="Instagram" href="" />
    <FooterLink label="Facebook" href="" />
    </div>
</div> */}