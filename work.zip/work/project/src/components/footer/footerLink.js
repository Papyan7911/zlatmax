// import React from 'react';

// const FooterLink = ({ label, href }) => {
//   return (
//     <p>
//       <a href={href} target="_blank" rel="noopener noreferrer">
//         {label}
//       </a>
//     </p>
//   );
// };

// export default FooterLink;
